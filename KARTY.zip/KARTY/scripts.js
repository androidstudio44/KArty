let promise = fetch('https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1');

let cards = document.querySelector('.cards')

promise.then(response => {
    return response.json();
}).then(json => {
    return fetch(`https://deckofcardsapi.com/api/deck/${json.deck_id}/draw/?count=15`);
}).then(response => {
    return response.json();
}).then(json => {
    json.cards.forEach(element => {
        let item = document.createElement('div');
        item.classList.add('item');
        item.innerHTML = `
            <div>
                <div class="item_title">${element.code}</div>
                <div class="item_img"><img src="${element.image}" alt=""></div>
                
                <div class="property">
                    <div>
                    <div>Value:</div>
                    <div>${element.value}</div>
                    </div>
                    <div>
                    <div>Suit:</div>
                    <div>${element.suit}</div>
                    </div>
                </div>
            </div>
        `;
        cards.append(item);
    });
})